export class JuegoPiedraPapelTijera {
}
