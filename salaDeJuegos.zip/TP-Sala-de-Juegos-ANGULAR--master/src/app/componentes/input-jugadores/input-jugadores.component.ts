import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input-jugadores',
  templateUrl: './input-jugadores.component.html',
  styleUrls: ['./input-jugadores.component.css']
})
export class InputJugadoresComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
