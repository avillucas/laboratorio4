
<?php
session_start();
if(isset($_SESSION['usuarioActual']))
{
echo  $_SESSION['usuarioActual'];
}
else
{
	header("location:index.php");
}

?><!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Sala de Juegos</title>

		<!--Estilos-->
		<link rel="stylesheet" type="text/css" href="../css/estilo.css">
		<link rel="stylesheet" type="text/css" href="../css/animacion.css">
		<!--final de Estilos-->

		<!--Lógica-Programación-->
		<script type="text/javascript" src="js/jsAdivinaElNumero2.js"></script>
        <!--Final de Lógica-Programación -->
		

		</head>
	<body>
		<div class="CajaUno animated bounceInDown">
			
		
			<form id="FormIngreso">

				<input type="text"  placeholder="Ingrese número" id="numero">
				
				<br>
				<input type="text"  placeholder="intentos" readonly id="intentos">
			</form>
			
		</div>
		<div class="CajaUno animated bounceInLeft">
			
		<button style="height:5em;" class="MiBotonUTN"  onclick="verificar()" >Verificar</button>
			
			<button  class="MiBotonUTN" onclick="comenzar()" >Comenzar</button>

		</div>

		<div class="CajaEnunciado animated bounceInLeft">
			<h2>Enunciado:</h2>
			
				<h3>
					1.	Adivina el número (v 2.0):
					En esta oportunidad el juego evaluará tus aptitudes a partir de la cantidad de intentos, por lo cual se informará lo siguiente:
					<br>	1° intento: “usted es un Psíquico”.
					<br>	2° intento: “excelente percepción”.
					<br>	3° intento: “Esto es suerte”.
					<br>	4° intento: “Excelente técnica”.
					<br>	5° intento: “usted está en la media”.
					<br>	Desde  6 Intentos hasta 10:”falta técnica”
					<br>	Más de 10 intentos: “afortunado en el amor!!”.


				</h3>
			
			
		</div>

		<div class="CajaAbajo animated bounceInUp">
				<a style=" margin-top: -10%;" class="MiBotonUTNLinea" onclick="location.href='../logout.php'" >Cerrar sesión</a>	

			<a  style=" margin-top: -20%;" class="MiBotonUTNLinea" onclick="location.href='../menu.php'" >Men&uacute; de juegos</a>	
			
		</div>
	</body>
</html>