<?php
session_start();
if(isset($_SESSION['usuarioActual']))
{
echo  $_SESSION['usuarioActual'];
}
else
{
	header("location:index.php");
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Sala De Juegos</title>

		<!--Estilos-->
		 <link rel="icon" href="http://www.octavio.com.ar/favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/estilo.css">
		<link rel="stylesheet" type="text/css" href="css/animacion.css">
		<!--final de Estilos-->

		<!--Lógica-Programación-->

        <!--Final de Lógica-Programación -->


	</head>
	<body>
		<div id="header">cabecera</div>
		<div class="CajaInicio animated bounceInRight"style="  margin-top: 55px;">
			<h1>Menú de Juegos</h1>
			<form id="FormIngreso">

				
				<img src="imagenes/tps.png" style="width: 500px;">

				<a  class="MiBotonUTNMenuInicio" onclick="location.href='juegos/AdivinaElNumero2.php'" >Adivina el número secreto</a>
				<a  class="MiBotonUTNMenuInicio" onclick="location.href='juegos/PiedraPapelTijera2.php'" >Piedra, papel o tijera </a>
				<a  class="MiBotonUTNMenuInicio" onclick="location.href='juegos/ReflejosDaltonicos1.php'" >Reflejos daltonicos</a>
				
	

			</form>


		</div>

		<center>

		</center>

	</body>
</html>
