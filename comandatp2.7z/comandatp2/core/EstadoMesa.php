<?php
namespace Core;


class EstadoMesa extends  Estado
{

}