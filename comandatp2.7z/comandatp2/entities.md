Comnada:


Bartender:Empleado 
Cervecero:Empleado
Cocinero:Empleado
Mozo:Empleado
Socio
Mesa 


EstadosPedido {
 PENDIENTES
 PREPARACION

}

Alimento
-nombre

Mesa
-codigo  alphanum 5 

comanda
-cliente string
-foto string 255
-alimentos Alimento[]
-codigo alphanum 5 char

comandaEstado
creado Datetime
tiempoEstimado Datetime
tiempoFinalizacion Datetime
estado  EstadoPedido
empleado Empleado



Los trabajos practicos son web 
