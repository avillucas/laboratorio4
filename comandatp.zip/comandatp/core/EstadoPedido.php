<?php
namespace Core;


class EstadoPedido extends  Estado
{

}