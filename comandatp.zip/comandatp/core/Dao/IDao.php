<?php
namespace Core\Dao;


interface IDao
{

    function save();
}