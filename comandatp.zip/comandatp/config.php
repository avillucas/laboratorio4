<?php
date_default_timezone_set('America/Argentina/Buenos_Aires');
define('DB_HOST','localhost');
define('DB_NAME','tp');

define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('SECRET','c0mand4pr3');
define('API_NAME','Comanda tp');
define('DEBUG', true );

define('JWT_SECRET','c0mand4pr3');